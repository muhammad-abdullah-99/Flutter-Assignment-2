import 'package:flutter/material.dart';

class Reels extends StatelessWidget {
  const Reels({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
