import 'package:flutter/material.dart';

class Igtv extends StatelessWidget {
  const Igtv({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
