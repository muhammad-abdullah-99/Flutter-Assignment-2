package com.example.instagram_profile_page

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
